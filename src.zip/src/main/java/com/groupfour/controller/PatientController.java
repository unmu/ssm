package com.groupfour.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.groupfour.entity.DiagnosisInfo;
import com.groupfour.entity.InspectionItem;
import com.groupfour.entity.RegisterInfo;
import com.groupfour.entity.Users;
import com.groupfour.service.DiagnosisService;
import com.groupfour.service.MedicineService;

@Controller
@RequestMapping("dt")
public class PatientController {

	@Autowired
	private DiagnosisService diagnosisService;
	
	@Autowired
	private MedicineService medicineService;
	
	@RequestMapping("optPatient")
	public String optPatientA(Model model,HttpSession session){
		List<RegisterInfo> registerList = new ArrayList<RegisterInfo>();
		Users users = (Users) session.getAttribute("users");
		registerList = diagnosisService.getRegisterInfoByDoctorId(users.getUserId());
		model.addAttribute("diagList", registerList);
		return "dt/optPatient";
	}
	
	@RequestMapping("dtInfoAdd")
	public String dtInfoAdd(Model model, String registerId){
		
		RegisterInfo registerInfo = diagnosisService.getRegisterInfoByRegisterId(registerId);
		model.addAttribute("registerInfo", registerInfo);
		return "dt/diagnosisInfoAdd";
	}
	
	@RequestMapping("saveDiagnosisInfo")
	@ResponseBody
	public boolean saveDiagnosisInfo(Model model, DiagnosisInfo diagnosisInfo){
		System.out.println("saveDiagnosisInfo");
		boolean flag = diagnosisService.insertDiagnosisInfo(diagnosisInfo);
		System.out.println(flag);
		return flag;
	}
	
	@RequestMapping("patientPerscription")
	public String patientPerscription(Model model, String registerId){
		RegisterInfo registerInfo = diagnosisService.getRegisterInfoByRegisterId(registerId);
		model.addAttribute("registerInfo", registerInfo);
		return "dt/patientPerscription";
	}
	
	//通过模糊查询药品信息
	@RequestMapping("searchItemInfoList")
	@ResponseBody
	public List<InspectionItem> searchItemInfoList(String itemName) {
			
		List<InspectionItem> list;
		list=medicineService.getInspectionItemList(itemName);
		System.out.println("查询检查信息的条数"+list.size());
		return list;
			
	}

}
